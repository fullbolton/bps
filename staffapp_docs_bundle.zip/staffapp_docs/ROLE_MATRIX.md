# ROLE_MATRIX.md

## Amaç

Bu dosya, StaffApp içindeki temel rollerin hangi yüzeyleri görebileceğini ve hangi aksiyonları yapabileceğini tanımlar.
Amaç, ilk sürümde rol mantığını gereksiz karmaşıklaştırmadan yetki kaosunu önlemektir.

Bu dosya güvenlik implementasyonu tarif etmez. Ürün seviyesi yetki mantığını tanımlar.

---

## 1. Rol tasarım ilkeleri

- İlk sürümde rol seti sade tutulmalıdır.
- Her kullanıcıya tam yetki verilmemelidir.
- "Görür ama düzenleyemez", ürün içinde ayrı bir ihtiyaçtır.
- Kritik kayıtlar için oluşturma, düzenleme ve silme yetkileri aynı kişide toplanmak zorunda değildir.
- Silme yerine pasife alma veya durum değiştirme tercih edilmelidir.

---

## 2. Önerilen başlangıç rol seti

İlk sürüm için 4 rol yeterlidir:

1. `yönetici`
2. `operasyon`
3. `satış`
4. `görüntüleyici`

Bu set, ürünü erken aşamada şişirmeden temel kullanım senaryolarını karşılar.

---

## 3. Rol tanımları

### 3.1 Yönetici

#### Rol amacı
Kurumsal görünürlük, kontrol, kritik aksiyon ve yapılandırma yönetimi.

#### Ana odak
- genel operasyon görünürlüğü,
- sözleşme ve yenileme riski,
- firma sağlığı,
- kritik görevler,
- sistem ayarları ve kullanıcılar.

#### Bu rol ne yapabilmeli
- tüm firmaları görüntüleme,
- firma oluşturma ve güncelleme,
- firma pasife alma,
- sözleşme oluşturma ve durum değiştirme,
- talep görüntüleme ve yönetme,
- randevu oluşturma ve sonuç girme,
- görev atama ve yeniden atama,
- evrak görüntüleme ve düzenleme,
- raporları görüntüleme,
- ayarlara erişim,
- kullanıcı/rol yönetimi.

#### Kısıt notu
- Yönetici her şeyi görür; ancak kritik veri silme aksiyonu ilk sürümde tercihen sınırlandırılır.

---

### 3.2 Operasyon

#### Rol amacı
Personel talebi, aktif iş gücü, evrak takibi ve operasyonel görev akışını yürütmek.

#### Ana odak
- açık talepler,
- doluluk açığı,
- firma bazlı operasyon,
- görevler,
- evrak eksikleri.

#### Bu rol ne yapabilmeli
- firmaları görüntüleme,
- firma detayına erişme,
- firma notu ekleme,
- personel talebi oluşturma ve güncelleme,
- aktif iş gücü görünümünü kullanma,
- randevu ekleme ve sonuç girme,
- görev oluşturma ve kendi görevlerini yönetme,
- evrak yükleme ve güncelleme,
- ilgili sözleşmeleri görüntüleme.

#### Bu rol neyi yapmamalı
- sistem ayarlarını değiştirme,
- kullanıcı/rol yönetimi,
- yüksek etkili sözleşme statüsü kararlarını tek başına değiştirme,
- firma pasife alma gibi yönetsel aksiyonlar.

---

### 3.3 Satış

#### Rol amacı
Firma ilişkisi, görüşme takibi, yenileme fırsatı ve müşteri teması.

#### Ana odak
- firma kartları,
- yetkililer,
- randevular,
- sözleşme takibi,
- yenileme fırsatları,
- notlar ve takip aksiyonları.

#### Bu rol ne yapabilmeli
- firmaları görüntüleme,
- firma oluşturma,
- firma notu ekleme,
- yetkili ekleme/düzenleme,
- randevu oluşturma,
- randevu sonucu ve sonraki aksiyon girme,
- sözleşmeleri görüntüleme,
- sözleşme için takip görevi oluşturma,
- kendi alanındaki raporları görüntüleme.

#### Bu rol neyi yapmamalı
- operasyonel aktif iş gücü verisini derin düzenleme,
- ayarlar ekranına müdahale,
- tüm kullanıcıları yönetme,
- kritik evrak kategorilerini veya sistem sözlüklerini değiştirme.

---

### 3.4 Görüntüleyici

#### Rol amacı
Yalnızca okuma ihtiyacı olan yöneticiler, destek kullanıcıları veya dış gözlemci senaryoları.

#### Ana odak
- görünürlük,
- takip,
- rapor okuma.

#### Bu rol ne yapabilmeli
- dashboard görüntüleme,
- firma detay görüntüleme,
- sözleşme görüntüleme,
- talep görüntüleme,
- görevleri okuma,
- evrakları görüntüleme,
- rapor görüntüleme.

#### Bu rol neyi yapmamalı
- kayıt oluşturma,
- kayıt düzenleme,
- görev atama,
- randevu sonucu girme,
- evrak yükleme,
- ayarlara erişim.

---

## 4. Yetki matrisi

Aşağıdaki tablo ürün seviyesinde önerilen başlangıç yetkilerini gösterir.

| Alan / Aksiyon | Yönetici | Operasyon | Satış | Görüntüleyici |
|---|---:|---:|---:|---:|
| Dashboard görüntüleme | Evet | Evet | Evet | Evet |
| Firma listesi görüntüleme | Evet | Evet | Evet | Evet |
| Firma oluşturma | Evet | Hayır | Evet | Hayır |
| Firma düzenleme | Evet | Sınırlı | Sınırlı | Hayır |
| Firma pasife alma | Evet | Hayır | Hayır | Hayır |
| Yetkili kişi ekleme/düzenleme | Evet | Sınırlı | Evet | Hayır |
| Sözleşme görüntüleme | Evet | Evet | Evet | Evet |
| Sözleşme oluşturma | Evet | Sınırlı | Sınırlı | Hayır |
| Sözleşme durum değiştirme | Evet | Hayır | Sınırlı | Hayır |
| Personel talebi görüntüleme | Evet | Evet | Evet | Evet |
| Personel talebi oluşturma | Evet | Evet | Sınırlı | Hayır |
| Personel talebi güncelleme | Evet | Evet | Sınırlı | Hayır |
| Aktif iş gücü görüntüleme | Evet | Evet | Sınırlı | Evet |
| Aktif iş gücü düzenleme mantığı | Evet | Evet | Hayır | Hayır |
| Randevu oluşturma | Evet | Evet | Evet | Hayır |
| Randevu sonucu girme | Evet | Evet | Evet | Hayır |
| Görev görüntüleme | Evet | Evet | Evet | Evet |
| Görev oluşturma | Evet | Evet | Evet | Hayır |
| Görev atama / yeniden atama | Evet | Sınırlı | Sınırlı | Hayır |
| Evrak görüntüleme | Evet | Evet | Sınırlı | Evet |
| Evrak yükleme | Evet | Evet | Sınırlı | Hayır |
| Evrak durumu güncelleme | Evet | Evet | Hayır | Hayır |
| Rapor görüntüleme | Evet | Sınırlı | Sınırlı | Evet |
| Ayarlar erişimi | Evet | Hayır | Hayır | Hayır |
| Kullanıcı / rol yönetimi | Evet | Hayır | Hayır | Hayır |

### Not
- `Sınırlı`, ürün içi daha dar kapsamlı düzenleme anlamına gelir.
- Detaylı erişim sınırları ekip yapısına göre daraltılabilir.

---

## 5. Alan bazlı yorumlar

### 5.1 Firmalar
- Firma oluşturma satış ve yönetici için açık olabilir.
- Firma pasife alma yönetici yetkisi olmalıdır.
- Operasyon ekibi firma üzerinde operasyon notu ekleyebilir ama ticari çekirdek alanları sınırlı değiştirmelidir.

### 5.2 Sözleşmeler
- Sözleşme, ürün içindeki en hassas iş alanlarından biridir.
- Görüntüleme geniş olabilir; durum değiştirme sınırlı tutulmalıdır.
- İmza / aktif / feshedildi gibi kararlar yönetsel kontrol altında olmalıdır.

### 5.3 Personel talepleri
- Operasyon bu alanın ana kullanıcısıdır.
- Satış talep açabilir ama operasyonel doluluk yönetimi operasyon rolünde olmalıdır.

### 5.4 Aktif iş gücü
- Satış rolü bunu daha çok görünürlük için kullanır.
- Operasyon ve yönetici, düzenleme ve takip tarafında daha geniş yetkili olur.

### 5.5 Randevular
- Satış ve operasyon birlikte kullanabilir.
- Yönetici tüm görünümü takip edebilir.
- Görüntüleyici sadece geçmiş ve planlı kayıtları görebilir.

### 5.6 Görevler
- Görevler ürünün koordinasyon katmanıdır.
- Görev atama sınırsız olmamalı; en azından rol bazlı filtrelenebilmelidir.

### 5.7 Evraklar
- Evrak yükleme operasyonel ihtiyaç olarak operasyon rolüne açılabilir.
- Kritik evrak kategorisi veya geçerlilik mantığı yönetici tarafından korunmalıdır.

### 5.8 Ayarlar
- Ayarlar ekranı yalnızca yöneticiye açık olmalıdır.
- İlk sürümde bu karar özellikle önemlidir; aksi halde sözlük ve yapı bozulur.

---

## 6. Kendi kaydını yönetme vs başkasının kaydını yönetme

İlk sürümde bazı alanlarda şu ayrım desteklenebilir:
- kişi kendi oluşturduğu kaydı düzenleyebilir,
- ancak başkasının kritik kaydını sınırsız düzenleyemez.

Bu ayrım özellikle şu alanlarda değerlidir:
- randevu,
- not,
- görev,
- bazı firma temas kayıtları.

---

## 7. Silme yerine güvenli aksiyon ilkesi

Aşağıdaki alanlarda fiziksel silme yerine güvenli aksiyon tercih edilmelidir:
- firma,
- sözleşme,
- görev,
- evrak,
- randevu.

Tercih edilen alternatifler:
- pasife alma,
- iptal etme,
- durumu kapatma,
- görünürlüğü azaltma.

Bu yaklaşım denetim izi ve kurumsal hafıza açısından daha doğrudur.

---

## 8. İlk sürüm için rol tasarım sınırı

İlk sürümde aşağıdakiler yapılmamalıdır:
- aşırı detaylı custom permission sistemi,
- alan alan bit seviyesinde yetki kurgusu,
- çok fazla ara rol üretimi,
- ürün ihtiyacı netleşmeden dış ekip / taşeron / müşteri portalı rolleri.

İlk sürüm hedefi: sade, anlaşılır ve yönetilebilir rol yapısı.

---

## 9. Rol kararları için değerlendirme soruları

Yeni bir rol veya yetki ihtiyacı geldiğinde önce şu sorular cevaplanmalıdır:

1. Bu ihtiyaç gerçekten yeni bir rol gerektiriyor mu?
2. Mevcut rollerden biri kapsam genişletilerek çözebilir mi?
3. Bu yetki ürün güveni veya veri bütünlüğü için risk yaratıyor mu?
4. Bu ayrım kullanıcı davranışını gerçekten değiştiriyor mu?

Bu sorular net değilse yeni rol eklenmemelidir.
