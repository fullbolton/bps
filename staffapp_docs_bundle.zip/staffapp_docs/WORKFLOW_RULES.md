# WORKFLOW_RULES.md

## Amaç

Bu dosya, StaffApp ürününün ekran tanımından bağımsız işleyiş kurallarını sabitler.
Amaç, ürünü generic CRM, belge arşivi veya tam HRIS çizgisine kaydırmadan;
**firma + sözleşme + personel temini + randevu/görev + evrak** omurgasında tutmaktır.

Bu dosya UI tarif etmez. Ürün davranışını tanımlar.

---

## 1. Çekirdek ürün akışı

Ürünün ana iş akışı aşağıdaki zincir etrafında kurulmalıdır:

**Firma → Sözleşme → Personel Talebi → Aktif İş Gücü → Randevu → Görev → Evrak / Uyarı / Risk**

Kurallar:
- Her kayıt mümkün olduğunda bir bağlama bağlı olmalıdır.
- Bağlamsız veri girişleri minimumda tutulmalıdır.
- Firma, sistemin ana üst varlığıdır.
- Firma detayı, ürünün ana çalışma yüzeyidir.
- Dashboard karar yüzeyidir; veri mezarlığı değildir.

---

## 2. Firma kuralları

### 2.1 Firma oluşturma
- Firma oluşturulmadan sözleşme, personel talebi ve firma bazlı randevu açılamaz.
- Her firma en az bir temel kimlik bilgisi ile açılmalıdır: firma adı.
- Firma oluşturulduğunda sistemde zaman çizgisine "firma oluşturuldu" olayı düşmelidir.

### 2.2 Firma durumu
- Firma en az şu durumlardan birinde olmalıdır: `aday`, `aktif`, `pasif`.
- `aktif` firma, operasyon ve sözleşme akışlarında görünür olmalıdır.
- `pasif` firma yeni operasyon için varsayılan listelerde öne çıkarılmamalıdır.

### 2.3 Firma pasife alma
- Firma pasife alınması alt kayıtları silmez.
- Firma pasife alındığında:
  - mevcut kayıtlar korunur,
  - geçmiş sözleşmeler korunur,
  - geçmiş randevular korunur,
  - görevler ayrı değerlendirilir,
  - sistem bunu zaman çizgisine işler.
- Firma pasife alınması, otomatik veri kaybı yaratmamalıdır.

### 2.4 Firma risk görünürlüğü
- Firma risk etiketi serbest karar değil; veri sinyalleriyle beslenmelidir.
- Risk seviyesini etkileyebilecek başlıca sinyaller:
  - yaklaşan sözleşme bitişi,
  - eksik evrak,
  - uzun süredir temas olmaması,
  - açık kalmış kritik talep,
  - yüksek çıkış / doluluk sorunu.

---

## 3. Sözleşme kuralları

### 3.1 Sözleşme bağlamı
- Her sözleşme bir firmaya bağlı olmalıdır.
- Sözleşme firmadan bağımsız düşünülemez.

### 3.2 Sözleşme yaşam döngüsü
- Sözleşme belge değil, süreç olarak ele alınmalıdır.
- Her sözleşmenin bir durum alanı olmalıdır.
- Her sözleşmenin başlangıç ve bitiş tarihi desteklenmelidir.
- Sözleşme değişiklikleri mümkünse versiyon mantığıyla izlenmelidir.

### 3.3 Yaklaşan bitiş kuralı
- Bitiş tarihine yaklaşan sözleşmeler dashboard ve ilgili listelerde görünür olmalıdır.
- Yaklaşan bitiş mantığı, ürün genelinde tutarlı olmalıdır.
- Aynı sözleşme için farklı ekranlarda farklı "yaklaşıyor" tanımları kullanılmamalıdır.

### 3.4 Yenileme kuralı
- Bitişi yaklaşan sözleşmeler için yenileme aksiyonu görünür olmalıdır.
- Yenileme görünürlüğü en az şu sinyalleri taşımalıdır:
  - sözleşme bitiş tarihi,
  - yenileme görüşmesi açıldı mı,
  - sorumlu kişi var mı,
  - ilgili görev üretildi mi.

### 3.5 Sözleşme durumu değişikliği
- Sözleşme durum değişiklikleri iz bırakmalıdır.
- Kritik durum değişiklikleri zaman çizgisine düşmelidir.
- Sözleşme silmek yerine durumsal kapatma veya pasif mantığı tercih edilmelidir.

---

## 4. Personel talebi kuralları

### 4.1 Talep bağlamı
- Her personel talebi bir firmaya bağlı olmalıdır.
- Talep, firma ile ilişkisiz açılmamalıdır.

### 4.2 Talep minimum alan mantığı
- Her talepte en az şu bilgiler bulunmalıdır:
  - firma,
  - pozisyon/görev tipi,
  - adet,
  - durum.

### 4.3 Talep sorumluluğu
- Talep açıldığında bir sorumlu atanması desteklenmelidir.
- Kritik veya yüksek öncelikli talepler sorumlusuz kalmamalıdır.

### 4.4 Talep durumu
- Talep durumları ürün genelinde tek sözlükten gelmelidir.
- Talep süreci şu mantığı taşımalıdır:
  - yeni,
  - değerlendiriliyor,
  - kısmi doldu,
  - tamamen doldu,
  - beklemede,
  - iptal.

### 4.5 Doluluk görünürlüğü
- Talep edilen sayı ile sağlanan sayı birbirinden ayrılmalıdır.
- Açık kalan sayı operasyon için görünür olmalıdır.
- Sistem, doluluk açığını firma ve operasyon görünümünde taşımalıdır.

---

## 5. Aktif iş gücü kuralları

### 5.1 Odak kuralı
- Aktif iş gücü ekranı tam çalışan özlük sistemi değildir.
- Bu ekranın amacı firma bazlı kapasite ve doluluk görünürlüğüdür.
- Bu modül bordro, izin, özlük veya detaylı çalışan yaşam döngüsüne kaydırılmamalıdır.

### 5.2 Ana metrikler
- Firma bazında aktif sayı görünmelidir.
- Hedef sayı ve açık fark mümkünse ayrı tutulmalıdır.
- Son dönem giriş/çıkış sinyalleri operasyonel risk açısından desteklenmelidir.

### 5.3 Risk sinyali
- Yüksek çıkış, düşük doluluk veya kritik açık fark firma riskine yansıyabilir.

---

## 6. Randevu kuralları

### 6.1 Randevu bağlamı
- Randevu mümkün olduğunda bir firmaya bağlı olmalıdır.
- Firma ilişkili randevular firma zaman çizgisinde görünmelidir.

### 6.2 Randevu kapanış disiplini
- `tamamlandı` durumundaki bir randevu sonuçsuz bırakılamaz.
- Randevu tamamlandıysa en az şu alanlar desteklenmelidir:
  - sonuç,
  - sonraki aksiyon.

### 6.3 Sonraki aksiyon mantığı
- Sonuç girilmiş ama takip gerektiren randevularda sonraki aksiyon görünür olmalıdır.
- Gerekirse randevudan görev üretilebilmelidir.

### 6.4 Randevu sonucu ve ürün değeri
- Takvim tek başına değer üretmez.
- Randevunun ürün içindeki değeri, sonucu ve takip aksiyonuyla oluşur.

---

## 7. Görev kuralları

### 7.1 Görev kaynağı
- Görevler mümkün olduğunda bir kaynağa bağlı olmalıdır.
- Desteklenen kaynak mantığı:
  - manuel,
  - randevu,
  - sözleşme,
  - talep,
  - evrak eksikliği.

### 7.2 Sahipsiz iş yasağı
- Kritik görevler atamasız bırakılmamalıdır.
- Görevler sorumlu, termin ve durum taşımalıdır.

### 7.3 Gecikme görünürlüğü
- Geciken görevler dashboard ve görev listesinde görünür olmalıdır.
- Gecikmiş görev, sadece renk değil aksiyon çağrısı da üretmelidir.

### 7.4 Görev tamamlama
- Görev tamamlandığında bu olay zaman çizgisine düşebilir.
- Görev kapandığında bağlı kayıtlar gerektiğinde güncellenebilir ama otomatik zincirleme değişiklik dikkatli tasarlanmalıdır.

---

## 8. Evrak kuralları

### 8.1 Evrak modülü tanımı
- Evrak modülü düz klasör sistemi değildir.
- Amaç dosya depolamaktan çok eksik ve riskli belge görünürlüğü üretmektir.

### 8.2 Evrak bağlamı
- Evraklar mümkün olduğunda ilgili bağlama bağlı olmalıdır:
  - firma,
  - sözleşme,
  - operasyonel kayıt.

### 8.3 Evrak durumu
- Evrakların sadece var/yok mantığı değil, geçerlilik mantığı da desteklenmelidir.
- Süresi yaklaşan evrak görünür olmalıdır.

### 8.4 Eksik evrak sinyali
- Eksik evrak bilgisi firma görünümüne ve risk sinyaline yansıyabilir.
- Eksik evraklı firmalar dashboard ve filtrelerde bulunabilmelidir.

---

## 9. Dashboard kuralları

### 9.1 Dashboard amacı
- Dashboard bir rapor çöplüğü değildir.
- Amaç, bugünkü operasyonel ve ticari öncelikleri öne çıkarmaktır.

### 9.2 Dashboard’a girmesi gereken sinyaller
- bugün yapılacak işler,
- yaklaşan sözleşme bitişleri,
- açık personel talepleri,
- eksik evraklar,
- geciken görevler,
- riskli firmalar.

### 9.3 Dashboard’a girmemesi gereken yaklaşım
- dekoratif grafik yükü,
- operasyon kararı üretmeyen metrik kalabalığı,
- ekranı doldurmak için eklenen düşük değerli kartlar.

---

## 10. Zaman çizgisi kuralları

### 10.1 Timeline amacı
- Zaman çizgisi, firma ilişkisinin kurumsal hafızasını tutar.
- Amaç geçmişi anlamayı hızlandırmaktır.

### 10.2 Zaman çizgisine düşebilecek olaylar
- firma oluşturuldu,
- yetkili eklendi,
- sözleşme eklendi,
- sözleşme durumu değişti,
- talep açıldı,
- randevu tamamlandı,
- görev tamamlandı,
- evrak yüklendi,
- kritik not eklendi.

### 10.3 Gürültü kontrolü
- Her küçük teknik değişiklik timeline’a düşmemelidir.
- Timeline ürünsel olarak anlamlı olayları taşımalıdır.

---

## 11. Risk motoru kuralları

### 11.1 Risk tek bir metne indirgenmemeli
- Risk etiketi, manuel yorum + sistem sinyali birleşimiyle oluşabilir.
- Risk görünürlüğü açıklanabilir olmalıdır.

### 11.2 Risk üretmesi muhtemel sinyaller
- sözleşme bitişi yakın ama aksiyon yok,
- eksik evrak,
- uzun süredir temas edilmemiş aktif müşteri,
- açık kalmış yüksek öncelikli talep,
- yüksek çıkış / düşük doluluk.

### 11.3 Kırmızı alarm enflasyonu olmamalı
- Her şey kritik gösterilirse hiçbir şey kritik değildir.
- Ürün kritik sinyalleri sınırlı ve güvenilir göstermelidir.

---

## 12. Veri giriş disiplini

### 12.1 Form disiplini
- İlk sürümde formlar gereksiz uzatılmamalıdır.
- Kullanıcıyı veri girişinden soğutacak ağır yapılar kurulmaz.

### 12.2 Zorunlu alan disiplini
- Sadece gerçekten süreç için kritik alanlar zorunlu yapılmalıdır.
- Zorunlu alanlar ürün akışını korumalı; veriyi keyfi zorlaştırmamalıdır.

### 12.3 Serbest metin kaosu
- Not alanları tamamen kontrolsüz bırakılmamalıdır.
- Mümkünse etiket, tarih ve yazan kişi mantığıyla desteklenmelidir.

---

## 13. Yetki ve rol mantığı

- Her kullanıcı her şeyi yapmamalıdır.
- Rol farkları özellikle şu alanlarda önemlidir:
  - firma yönetimi,
  - sözleşme yönetimi,
  - evrak yükleme,
  - görev atama,
  - rapor erişimi,
  - ayarlar.

Rol detayları ayrı dosyada (`ROLE_MATRIX.md`) tanımlanmalıdır.

---

## 14. Anti-pattern listesi

Aşağıdaki yönelimler bilinçli olarak reddedilir:

### 14.1 Generic CRM’ye kaymak
- aşırı satış pipeline ekranları,
- kampanya otomasyonları,
- e-posta pazarlama mantığı,
- ilişkiden kopuk lead yapıları.

### 14.2 Tam HRIS’ye kaymak
- detaylı çalışan özlük yönetimi,
- bordro ve izin çekirdeği,
- derin çalışan yaşam döngüsü kurgusu.

### 14.3 Sadece belge deposu kurmak
- klasör bazlı pasif arşiv yaklaşımı,
- süreç üretmeyen evrak modülü.

### 14.4 Dashboard şişirmek
- operasyon kararı üretmeyen görsel yoğunluk,
- gereksiz chart kalabalığı,
- click-through değeri olmayan kartlar.

---

## 15. Karar öncelik sırası

Yeni bir özellik veya değişiklik değerlendirilirken sıra şu olmalıdır:

1. Ürün omurgasına hizmet ediyor mu?
2. Firma detay merkezini güçlendiriyor mu?
3. Sözleşme / talep / randevu / görev zincirini netleştiriyor mu?
4. Risk, yenileme veya operasyon görünürlüğünü artırıyor mu?
5. Generic CRM / HRIS kayması yaratıyor mu?

Bu sıraya girmeyen eklemeler temkinli değerlendirilmelidir.
