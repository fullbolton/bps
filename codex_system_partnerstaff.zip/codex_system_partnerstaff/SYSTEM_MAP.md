# SYSTEM_MAP.md

## Amaç
Bu dosya, ürünün bilgi mimarisini ve modül ilişkilerini tanımlar.

---

## Ana Modüller
1. Dashboard
2. Firmalar
3. Sözleşmeler
4. Personel Talepleri
5. Aktif İş Gücü
6. Randevular
7. Görevler
8. Evraklar
9. Raporlar
10. Ayarlar

---

## Çekirdek Varlıklar
- Firma
- Yetkili
- Sözleşme
- Personel Talebi
- Aktif İş Gücü Özeti
- Randevu
- Görev
- Evrak
- Not
- Timeline Event

---

## İlişki Haritası

### Firma
Merkez varlıktır.
Şunlara bağlanır:
- Yetkililer
- Sözleşmeler
- Personel Talepleri
- Aktif İş Gücü
- Randevular
- Evraklar
- Notlar
- Timeline

### Sözleşme
Bir firmaya bağlıdır.
Şunlara bağlanabilir:
- görevler
- randevular
- dosya/versiyonlar
- yenileme aksiyonları

### Personel Talebi
Bir firmaya bağlıdır.
Şunlara bağlanabilir:
- görevler
- randevular
- iç notlar

### Aktif İş Gücü
Firma bazlı operasyon görünürlüğüdür.
Talep ile ilişkilidir ama bireysel HR ekranı değildir.

### Randevu
Bir firmaya bağlıdır.
İsteğe bağlı olarak şu kayıtlara bağlanabilir:
- sözleşme
- personel talebi
- görev

### Görev
Aşağıdaki kaynaklardan doğabilir:
- manuel
- randevu
- sözleşme
- personel talebi
- evrak eksikliği

### Evrak
Bir firmaya veya bir sözleşmeye bağlanabilir.
Geçerlilik ve eksiklik mantığı taşır.

---

## Ana Akışlar

### Akış 1 — Firma yönetimi
Dashboard → Firma listesi → Firma detay → alt sekmeler

### Akış 2 — Sözleşme yaşam döngüsü
Firma detay / Sözleşme listesi → Sözleşme detay → durum / yenileme / görev

### Akış 3 — Personel temini görünürlüğü
Firma detay / Talepler listesi → Talep → doluluk → aktif iş gücü özeti

### Akış 4 — Randevu sonrası aksiyon
Randevu → sonuç → sonraki aksiyon → görev

### Akış 5 — Evrak ve uygunluk görünürlüğü
Firma detay / Evraklar → checklist → eksik / süresi yaklaşan → görev / uyarı

---

## Navigasyon Mantığı
Ana gezinme omurgası:
- Dashboard karar ekranı
- Firma detay bağlam ekranı
- Modül listeleri operasyon listesi
- Detay sayfaları aksiyon ekranı

---

## Kritik Ürün Gerçeği
Bu sistemde veri girişinden çok **bağlamlı görünürlük** önemlidir.
Tek başına liste üretmek yeterli değildir.
Her ana yüzey bir sonraki doğru kararı kolaylaştırmalıdır.
