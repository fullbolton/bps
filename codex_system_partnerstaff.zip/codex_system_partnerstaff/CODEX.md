# CODEX.md

## Amaç
Bu dosya, Codex için **ana giriş kapısı**dır. Codex yeni bir oturuma başladığında önce bu dosyayı okuyarak:
- ürünün ne olduğunu,
- ne olmadığını,
- hangi dosyaların hangi sırayla okunacağını,
- nasıl karar verileceğini,
- hangi anti-pattern'lerden kaçınılacağını
öğrenir.

Bu sistem, **Partner Staff ofis içi operasyon arayüzü** için hazırlanmıştır.

---

## Ürün Tanımı
Bu ürün generic CRM değildir.
Bu ürün yalnızca belge arşivi de değildir.
Bu ürün tam ölçekli İK / bordro / ERP sistemi de değildir.

Doğru tanım:

**Şirketlerle olan ticari ilişkiyi, sözleşme yaşam döngüsünü ve personel temini operasyonunu tek panelden yöneten ofis içi operasyon arayüzü.**

Merkez varlıklar:
- Firma
- Sözleşme
- Personel Talebi
- Aktif İş Gücü
- Randevu
- Görev
- Evrak
- Not / Zaman Çizgisi

Çekirdek omurga:

**Dashboard → Firma Detay → Sözleşme / Talep / Randevu → Görev → Uyarı kapanışı**

---

## Codex'in Rolü
Codex'in görevi:
- ürün kapsamını korumak,
- ekran ve akışları bu sistem dokümanlarına göre üretmek,
- gereksiz kapsam genişlemesini engellemek,
- bileşen tekrarını azaltmak,
- ortak tasarım dili ve bilgi mimarisi tutarlılığını korumaktır.

Codex'in görevi olmayan şeyler:
- ürünü generic CRM'e çevirmek,
- tam HRIS / bordro / özlük sistemi önermek,
- muhasebe ERP katmanı tasarlamak,
- gereksiz rapor ve grafik şişirmesi yapmak,
- ürün odağını kaybettirecek ek modüller önermek.

---

## Okuma Sırası (Zorunlu)
Codex yeni bir iş almadan önce bu sırayla okur:

1. `CODEX.md`
2. `SKILLS.md`
3. `SYSTEM_MAP.md`
4. `PRODUCT_STRUCTURE.md`
5. `SCREEN_SPEC.md`
6. `COMPONENT_SYSTEM.md`
7. `BUILD_PRIORITY.md`

Bu sıranın amacı:
- önce rol ve sınır,
- sonra karar ilkeleri,
- sonra bilgi mimarisi,
- sonra ekranlar,
- sonra component sistemi,
- en son inşa sırası.

---

## Temel Karar İlkeleri
Her öneri veya üretim şu 5 sorudan geçmeli:

1. Bu, firmanın operasyonel görünürlüğünü artırıyor mu?
2. Bu, sözleşme / yenileme riskini daha görünür kılıyor mu?
3. Bu, personel talebi ve doluluk durumunu daha iyi yönetiyor mu?
4. Bu, randevu → aksiyon → görev zincirini güçlendiriyor mu?
5. Bu, sistemi generic CRM'e doğru kaydırıyor mu?

İlk 4 sorudan en az birine güçlü katkı vermeyen ve 5. soruda riski olan şeyler reddedilmelidir.

---

## Ürün Merkezleri
Bu ürünün en kritik 3 ekranı:

1. **Firma Detay**
2. **Dashboard**
3. **Sözleşmeler**

Neden:
- ilişki ve operasyon bilgisi firma detayda toplanır,
- sabah yönetimi dashboard'dan yapılır,
- gelir kaçağı ve yenileme riski sözleşmelerde görünür.

---

## Zorunlu UX Prensipleri
- Liste ekranları geçiş ekranıdır; asıl iş detay ekranlarında çözülmelidir.
- Her kayıt ilgili bağlama bağlı olmalıdır.
  - randevu → görev
  - sözleşme → uyarı / yenileme
  - talep → doluluk takibi
  - evrak → eksik / geçerlilik riski
- Boş state'ler her zaman bir sonraki aksiyonu önermelidir.
- Formlar ilk sürümde kısa tutulmalıdır.
- Dashboard KPI çöplüğüne dönüştürülmemelidir.
- Randevu tamamlandıysa sonuç ve sonraki aksiyon boş bırakılamamalıdır.

---

## Scope Guardrails
Codex aşağıdaki alanlara V1 içinde genişleme önermemelidir:
- tam bordro yönetimi
- tam özlük yönetimi
- maaş / tahakkuk / finans ERP akışları
- email marketing / campaign CRM
- gelişmiş satış pipeline otomasyonu
- çalışan bazlı ağır performans sistemleri

V1 odağı:
- firmalar
- sözleşmeler
- personel talepleri
- aktif iş gücü görünürlüğü
- randevular
- görevler
- evraklar
- temel raporlama

---

## Çıktı Beklentisi
Codex bir görev aldığında çıktısını şu sırayla kurmalıdır:
1. Problem tanımı
2. Bu işin ürün omurgasındaki yeri
3. Etkilenen ekranlar / bileşenler
4. Gerekli yeni component var mı, yoksa mevcutla çözülür mü
5. Scope riski var mı
6. Önerilen çözüm

---

## Son Not
Bu sistemin başarısı yeni modül sayısına değil, şu 4 akışın netliğine bağlıdır:
- firma yönetimi
- sözleşme yaşam döngüsü
- personel talebi / doluluk görünürlüğü
- randevu sonrası aksiyon disiplini
