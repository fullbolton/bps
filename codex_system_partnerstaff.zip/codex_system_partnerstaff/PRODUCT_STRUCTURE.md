# PRODUCT_STRUCTURE.md

## Sol Menü
1. Dashboard
2. Firmalar
3. Sözleşmeler
4. Personel Talepleri
5. Aktif İş Gücü
6. Randevular
7. Görevler
8. Evraklar
9. Raporlar
10. Ayarlar

---

## Üst Bar
Her ekranda sabit olacak ortak alanlar:
- global arama
- hızlı ekle butonu
- bildirim / uyarı ikonu
- kullanıcı menüsü

### Hızlı Ekle Menüsü
- Yeni firma
- Yeni randevu
- Yeni sözleşme
- Yeni görev
- Yeni personel talebi
- Evrak yükle

---

## Dashboard
### Amaç
Sabah ilk bakışta operasyon ve risk görünürlüğü vermek.

### Göstermesi Gerekenler
- aktif firma sayısı
- aktif sözleşme sayısı
- açık personel talebi
- aktif verilen iş gücü
- bu hafta randevu sayısı
- kritik uyarı sayısı
- bugün yapılacaklar
- yaklaşan sözleşmeler
- açık talepler
- eksik evraklı firmalar
- riskli firmalar
- son aktiviteler

---

## Firmalar
### Amaç
Portföyü görmek, filtrelemek ve firma detaya geçmek.

### Liste kolonları
- firma adı
- sektör
- şehir
- ana yetkili
- aktif sözleşme
- aktif iş gücü
- son görüşme
- sonraki randevu
- risk etiketi
- durum

### Firma Detay Sekmeleri
- Genel Bakış
- Yetkililer
- Sözleşmeler
- Talepler
- Aktif İş Gücü
- Randevular
- Evraklar
- Notlar
- Zaman Çizgisi

---

## Sözleşmeler
### Amaç
Sözleşmeleri belge olarak değil, yaşam döngüsü olarak yönetmek.

### Liste kolonları
- sözleşme adı
- firma
- tür
- başlangıç
- bitiş
- kalan gün
- durum
- sorumlu
- son işlem

### Detay bölümleri
- dosya & versiyonlar
- kritik maddeler özeti
- yenileme takibi
- bağlı görevler
- bağlı randevular
- iç notlar

---

## Personel Talepleri
### Amaç
Açık ihtiyaçları, doluluk durumunu ve operasyon baskısını yönetmek.

### Liste kolonları
- firma
- pozisyon
- talep edilen
- sağlanan
- açık kalan
- lokasyon
- başlangıç tarihi
- öncelik
- durum
- sorumlu

---

## Aktif İş Gücü
### Amaç
Firma bazlı verilmiş iş gücünü ve doluluk riskini göstermek.

### Liste kolonları
- firma
- lokasyon
- aktif kişi
- hedef kişi
- açık fark
- son 30 gün giriş
- son 30 gün çıkış
- risk etiketi

---

## Randevular
### Amaç
Görüşmeyi değil, sonucu ve sonraki aksiyonu yönetmek.

### Liste kolonları
- tarih
- firma
- görüşme tipi
- katılımcı
- durum
- sonuç
- sonraki aksiyon

---

## Görevler
### Amaç
Sahipsiz işi ortadan kaldırmak.

### Liste kolonları
- görev başlığı
- bağlı firma
- kaynak
- atanan kişi
- termin
- öncelik
- durum

---

## Evraklar
### Amaç
Belge deposu değil; eksik ve süresi dolan evrak görünürlüğü.

### Liste kolonları
- evrak adı
- firma
- kategori
- geçerlilik tarihi
- durum
- yükleyen
- güncellenme tarihi

---

## Raporlar
### İlk Rapor Seti
- firma bazlı aktif iş gücü
- yaklaşan sözleşme bitişleri
- açık / kapanan talep analizi
- randevu hacmi ve sonuçlar
- riskli firma listesi

---

## Ayarlar
### Sekmeler
- Kullanıcılar
- Roller
- Firma etiketleri
- Sözleşme tipleri
- Evrak kategorileri
- Görev tipleri
- Bildirim kuralları
