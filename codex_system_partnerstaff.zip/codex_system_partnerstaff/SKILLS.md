# SKILLS.md

## Amaç
Bu dosya, Codex'in davranış kurallarını ve karar kalitesini tanımlar.

---

## Skill 1 — Önce problemi tanımla
Hiçbir ekran, tablo veya component üretimine doğrudan atlama.
Önce şu soruyu cevapla:

**Bu yüzey hangi operasyonel problemi çözüyor?**

---

## Skill 2 — Generic CRM refleksini bastır
Müşteri kartı, pipeline, kampanya ve lead mantığına kayma.
Bu ürünün merkezi:
- firma ilişkisi
- sözleşme yaşam döngüsü
- personel temini operasyonu
- görev ve takip disiplini

---

## Skill 3 — Firma detayı merkez kabul et
Yeni bir özellik düşünülüyorsa ilk soru şudur:

**Bu bilgi firma detay ekranında nasıl temsil edilecek?**

Firma detay dışında yaşayan dağınık bilgiler uzun vadede ürün kalitesini düşürür.

---

## Skill 4 — Liste değil karar üret
Liste ekranı üretmek kolaydır.
Asıl amaç karar vermeyi hızlandırmaktır.
Her tablo veya kart için şu soruyu sor:

**Kullanıcı bu görünümden sonra ne karar alacak?**

---

## Skill 5 — Sözleşme sadece dosya değildir
Her sözleşme yüzeyinde şunlar görünür olmalıdır:
- başlangıç / bitiş
- durum
- sorumlu
- yenileme gerekliliği
- bağlı görevler
- bağlı randevular

Sadece PDF saklamak ürün değeri oluşturmaz.

---

## Skill 6 — Randevu sonuçsuz kapanamaz
Randevu tamamlandı ise en az şu alanlar boş bırakılamaz:
- sonuç
- sonraki aksiyon
- tarih veya sorumlu

Bu disiplin ürün kullanım kalitesini belirler.

---

## Skill 7 — Aktif iş gücü ekranını HRIS'e çevirme
Bu yüzey bireysel çalışan özlük ekranı değildir.
Merkezde firma bazlı görünürlük vardır:
- aktif sayı
- hedef sayı
- açık fark
- giriş/çıkış özeti
- risk

---

## Skill 8 — Evrak modülünü klasör sistemi gibi kurma
Evrak modülü yalnızca yükleme alanı değildir.
Şunları göstermelidir:
- gerekli / eksik
- geçerlilik tarihi
- süresi yaklaşanlar
- firma bazlı checklist

---

## Skill 9 — Tekrar eden yapıları componentleştir
Aşağıdaki pattern'ler tekrar edecek:
- summary header
- status badge
- risk badge
- filter bar
- detail drawer
- checklist kartı
- activity list
- timeline

Yeni ekran için yeni component yazmadan önce mevcut ortak pattern'e bak.

---

## Skill 10 — Dashboard'u sade tut
Dashboard her şeyi gösteren ekran değildir.
Sadece karar aldıran kritik sinyalleri göstermelidir:
- yaklaşan sözleşmeler
- açık talepler
- bugünkü randevular
- eksik evraklar
- geciken görevler
- riskli firmalar

---

## Skill 11 — Boş state, aksiyon içermeli
Boş state yalnızca boş bilgi vermemeli.
Doğru aksiyona yönlendirmeli.
Örnek:
- “Henüz aktif sözleşme yok. Yeni sözleşme ekleyin.”
- “Bu firmaya ait açık talep yok. Yeni talep oluşturun.”

---

## Skill 12 — Önceliği bilgi mimarisine ver
UI kararı verirken önce şu sırayı izle:
1. bilgi nerede yaşamalı
2. hangi ekrana bağlı olmalı
3. nasıl filtrelenmeli
4. nasıl görüntülenmeli
5. ancak sonra görsel detay

---

## Skill 13 — Sağ paneli sadece yoğun bağlamda kullan
Right-side panel her yerde kullanılmaz.
Sadece yoğun bağlam gereken yüzeylerde kullanılmalıdır:
- sözleşme detay
- firma detay
- talep detay drawer
- randevu detay

---

## Skill 14 — V1 ve V1.1 ayrımını koru
V1:
- dashboard
- firmalar
- firma detay
- sözleşmeler
- personel talepleri
- aktif iş gücü
- randevular
- görevler
- evraklar

V1.1:
- zaman çizgisi derinliği
- firma sağlık skoru
- yenileme merkezi
- daha gelişmiş raporlar

---

## Skill 15 — Her öneride anti-pattern kontrolü yap
Şu sapmaları kontrol et:
- generic CRM'e kayma
- ERP'ye kayma
- HRIS'e kayma
- gereksiz tablo çoğaltma
- bileşen patlaması
- rapor şişmesi

Bir öneri bu risklerden birini yükseltiyorsa açıkça belirtilmelidir.
