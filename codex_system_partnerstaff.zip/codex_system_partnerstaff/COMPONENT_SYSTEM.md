# COMPONENT_SYSTEM.md

## Amaç
Bu dosya, ürün genelinde tekrar edecek component sistemini ve tekrar kullanım mantığını tanımlar.

---

## Ortak Temel Componentler
- `PageHeader`
- `KPIStatCard`
- `FilterBar`
- `SearchInput`
- `StatusBadge`
- `PriorityBadge`
- `RiskBadge`
- `DataTable`
- `EmptyState`
- `ActivityFeed`
- `DetailDrawer`
- `RightSidePanel`
- `TimelineList`
- `NotesComposer`
- `ChecklistCard`
- `QuickActionMenu`
- `ConfirmModal`

---

## Domain-Specific Componentler
- `FirmaSummaryCard`
- `ContractExpiryCard`
- `WorkforceCapacityCard`
- `AppointmentResultCard`
- `MissingDocumentCard`
- `RenewalOpportunityCard`
- `TaskSourceBadge`

---

## Tekrar Kullanım Kuralları

### 1. Header standardizasyonu
Liste ve detay ekranlarında mümkün olduğunca ortak header yapısı kullanılmalı.
Header içinde genellikle:
- başlık
- özet bilgi
- aksiyon butonları
olmalı.

### 2. Badge standardizasyonu
Durum, öncelik ve risk için ayrı ayrı ama tutarlı badge sistemleri kullanılmalı.
Aynı anlam farklı ekranlarda farklı renkle veya farklı sözcükle anlatılmamalı.

### 3. Table standardizasyonu
Tüm ana listelerde ortak tablo davranışı kullanılmalı:
- arama
- filtre
- sıralama
- satır tıklama
- aksiyon menüsü
- boş state

### 4. Drawer / side panel standardizasyonu
Yoğun detay ihtiyacı olan ama yeni sayfa açılmadan çözülebilecek bağlamlar drawer ile çözülmeli.
Örnek:
- talep satırı detayları
- randevu detay özeti
- sözleşme hızlı önizleme

### 5. Checklist standardizasyonu
Evrak ve uyum benzeri alanlarda checklist pattern'i ortak olmalı:
- gerekli
- mevcut
- eksik
- süresi yaklaşıyor

### 6. Timeline standardizasyonu
Timeline, firma özelinde ve genel activity feed tarafında benzer mantıkla çalışmalı:
- olay tipi
- tarih
- kullanıcı
- ilgili kayıt

---

## Yeni Component Açma Kuralı
Yeni component açmadan önce şu kontrol yapılmalı:
1. Bu görünüm mevcut bir ortak component varyantı ile çözülebilir mi?
2. Yalnızca bu ekrana özel mi, yoksa en az 2-3 yerde tekrar edecek mi?
3. Domain-specific component olarak ayrılması gerçekten okunabilirliği artırıyor mu?

Bu soruların cevabı zayıfsa yeni component açılmamalı.

---

## Anti-Patternler
- aynı işi yapan birden çok badge component
- ekran bazlı özel tablo bileşenleri
- çok erken ayrıştırılmış mikro component patlaması
- ortak davranışların kopya kodla çoğalması
- bilgi mimarisi problemi olan şeyi component problemi sanmak
