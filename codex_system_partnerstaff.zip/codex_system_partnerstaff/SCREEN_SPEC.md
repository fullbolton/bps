# SCREEN_SPEC.md

## Dashboard — Bileşen Listesi
- PageHeader
- DateRangePicker
- GlobalSearch
- QuickAddButton
- KPIStatCard x6
- TodayTasksCard
- ContractExpiryCard
- OpenDemandCard
- MissingDocumentCard
- RiskyCompaniesCard
- ActivityFeed

---

## Firmalar Liste — Bileşen Listesi
- PageHeader
- SearchInput
- FilterBar
- SavedFilterChips
- DataTable
- RowActionMenu
- NewCompanyModal
- QuickNoteModal

---

## Firma Detay — Header
- FirmaSummaryHeader
- RiskBadge
- StatusBadge
- QuickActionButtons
- TabNavigation

### Genel Bakış
- ActiveContractsCard
- OpenRequestsCard
- WorkforceSummaryCard
- UpcomingAppointmentsCard
- MissingDocumentsCard
- LatestNotesCard
- RiskSignalsCard

### Yetkililer
- ContactsTable
- AddContactModal

### Sözleşmeler
- ContractsTable
- FilterChips
- AddContractButton

### Talepler
- RequestsTable
- RequestSummaryCards
- AddRequestButton

### Aktif İş Gücü
- WorkforceSummaryCard
- PositionDistributionCard
- HireExitSummaryCard
- CapacityRiskCard
- WorkforceTable

### Randevular
- AppointmentsTable
- StatusFilters
- AddAppointmentButton
- AppointmentDetailDrawer

### Evraklar
- DocumentsChecklistCard
- DocumentsTable
- UploadDocumentButton

### Notlar
- NotesComposer
- TagFilter
- PinnedNotesSection
- NotesFeed

### Zaman Çizgisi
- TimelineList
- EventTypeFilter

---

## Sözleşmeler Liste — Bileşen Listesi
- PageHeader
- FilterBar
- SummaryChips
- DataTable
- RightPreviewPanel
- NewContractModal
- RenewalTaskModal

---

## Sözleşme Detay — Bileşen Listesi
- ContractSummaryHeader
- ActionButtons
- FileVersionsList
- CriticalClausesEditor
- RenewalTrackingCard
- LinkedTasksList
- LinkedAppointmentsList
- InternalNotesSection

---

## Personel Talepleri — Bileşen Listesi
- PageHeader
- FilterBar
- SummaryCards
- DataTable
- RequestDetailDrawer
- NewRequestModal
- AssignOwnerModal

---

## Aktif İş Gücü — Bileşen Listesi
- KPIStatCards
- FilterBar
- DataTable
- ExpandableRowDetails

---

## Randevular — Bileşen Listesi
- ViewSwitch
- PageHeader
- FilterBar
- DataTable
- AppointmentDetailPanel
- NewAppointmentModal
- AppointmentResultModal
- CreateTaskModal

---

## Görevler — Bileşen Listesi
- PageHeader
- FilterBar
- SummaryCards
- DataTable
- QuickActionMenu
- NewTaskModal

---

## Evraklar — Bileşen Listesi
- PageHeader
- FilterBar
- ChecklistSummaryCards
- DataTable
- FirmDocumentChecklistPanel
- UploadDocumentModal
- UpdateValidityModal

---

## Raporlar — Bileşen Listesi
- ReportSwitcher
- DateRangePicker
- TableArea
- ExportActions

---

## Ayarlar — Bileşen Listesi
- Tabs
- DataTable
- AddEditModal
- StatusToggle
