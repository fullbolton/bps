# BUILD_PRIORITY.md

## Amaç
Bu dosya, hangi ekran ve component setinin hangi sırayla inşa edilmesi gerektiğini tanımlar.

---

## Öncelik Mantığı
Önce ürün omurgası kurulmalı.
Sonra operasyon derinliği eklenmeli.
En son verimlilik ve raporlama katmanı gelmeli.

---

## Paket 1 — İskelet
Önce ortak altyapı:
- Layout
- Sidebar
- Topbar
- PageHeader
- KPIStatCard
- DataTable
- StatusBadge
- FilterBar
- SearchInput
- EmptyState

Amaç:
Tüm sistemin ortak çerçevesini kurmak.

---

## Paket 2 — Çekirdek Yüzeyler
- Dashboard
- Firmalar listesi
- Firma detay header
- Firma detay genel bakış
- Sözleşmeler listesi

Amaç:
Ürün omurgasını ilk kez kullanılabilir hale getirmek.

---

## Paket 3 — Ticari ve Takip Derinliği
- Sözleşme detay
- Randevular
- Görevler

Amaç:
Sözleşme riski, görüşme disiplini ve aksiyon zincirini görünür kılmak.

---

## Paket 4 — Operasyon Derinliği
- Personel Talepleri
- Aktif İş Gücü
- Evraklar

Amaç:
Ofis operasyonunu tam görünür hale getirmek.

---

## Paket 5 — Yönetim ve Zeka Katmanı
- Raporlar
- Zaman Çizgisi
- Firma sağlık skoru
- Yenileme merkezi

Amaç:
Yönetim görünürlüğü ve kalite katmanını artırmak.

---

## V1 Kapsamı
- Dashboard
- Firmalar
- Firma detay
- Sözleşmeler
- Personel Talepleri
- Aktif İş Gücü
- Randevular
- Görevler
- Evraklar

---

## V1.1 Kapsamı
- Zaman çizgisi derinleştirme
- Firma sağlık skoru
- Yenileme merkezi
- Gelişmiş raporlar

---

## Red Flags
Aşağıdaki işler öncelik sırasını bozar:
- önce raporlara girip çekirdek akışları eksik bırakmak
- ortak component sistemi kurulmadan ekran çoğaltmak
- firma detay çözülmeden yan modüllere yatırım yapmak
- aktif iş gücü ekranını çalışan özlük sistemine çevirmek
- evrak modülünü yalnızca klasör ekranı gibi yapmak
