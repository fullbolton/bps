# Partner Staff — Codex System Pack

Bu klasör, Partner Staff ofis içi operasyon arayüzü için Codex'e verilecek markdown tabanlı yönlendirme sistemidir.

## Dosyalar
- `CODEX.md` → ana giriş kapısı, rol, scope, okuma sırası
- `SKILLS.md` → davranış ve karar kalitesi kuralları
- `SYSTEM_MAP.md` → modül / varlık / akış ilişkileri
- `PRODUCT_STRUCTURE.md` → bilgi mimarisi ve ekran yapısı
- `SCREEN_SPEC.md` → sayfa bazlı component listeleri
- `COMPONENT_SYSTEM.md` → ortak component sistemi ve tekrar kullanımı
- `BUILD_PRIORITY.md` → inşa önceliği ve kapsam sırası

## Önerilen Kullanım
Yeni bir Codex oturumunda ilk prompt'a şu komut eklenebilir:

"Önce README.md, ardından CODEX.md, SKILLS.md, SYSTEM_MAP.md, PRODUCT_STRUCTURE.md, SCREEN_SPEC.md, COMPONENT_SYSTEM.md ve BUILD_PRIORITY.md dosyalarını sırayla oku. Bu dosyaları source of truth kabul et. Generic CRM, ERP veya HRIS kapsamına kayma. Önce problem tanımı yap, sonra öneri üret."

## Kısa Not
Bu sistem ürünün merkezini şu 4 akışta sabitler:
- firma yönetimi
- sözleşme yaşam döngüsü
- personel talebi / doluluk görünürlüğü
- randevu sonrası aksiyon disiplini
